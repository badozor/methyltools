betaUHM <- function(df,n=10000,initial=c(0.2,0.75),niter=25,tol=1e-4,cpus=4,type="postcluster",moda=c("U","H","M"),...){
	if(!is.element(type,c("model","meancluster","postcluster","postproba")))
		stop("non convenient option!")
	warnings("betaUHM with try test (in constructiuon)")
	if(cpus>1){
		require(snowfall)
		sfStop()
		sfInit(parallel=TRUE, cpus=cpus)
		sfLibrary(RPMM)
		sfExport("beta3mix",namespace="methyltools")
		sfExport("blcmodif",namespace="methyltools")
		sfExport("df")
		sfExport("n")
		sfExport("initial")
		sfExport("niter")
		sfExport("tol")
		res <- sfApply(df,2,function(x) try(beta3mix(x,n=n,initial=initial,niter=niter,tol=tol)),...)
		sfStop()
	}else{
		res <- apply(df,2,function(x) try(beta3mix(x,n=n,initial=initial,niter=niter,tol=tol)))	
	}
	names(res) <- colnames(df)
	if(length(moda)!=3)
		stop("non convenient dimension!")		
	if(type=="model"){
		return(res)
	}else if(type=="meancluster"){
		auxi <- as.data.frame(do.call("cbind",lapply(res,function(x) moda[match(x$meancluster,c(1,2,3))])))
		return(auxi)
	}else if(type=="postcluster"){
		auxi <- as.data.frame(do.call("cbind",lapply(res,function(x) moda[match(x$postcluster,c(1,2,3))])))
		return(auxi)
	}else if(type=="postproba"){
		auxi <- lapply(res,function(x) x$postw)
		names(auxi) <-names(res)
		return(auxi)
	}
}