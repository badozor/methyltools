### 2016-02-10 modified by pbady ###
combiUHM <- function(x,rare=NULL,mc=1000){
	auxi <- as.data.frame(x)
	levelUM <- apply(expand.grid(lapply(1:ncol(auxi),function(...) rep(c("U","M")))),1,paste,collapse="")
	for(i in 1:ncol(x))
		auxi[,i] <- c("U","M","M")[match(auxi[,i],c("U","H","M"))]
	auxi <- factor(apply(auxi,1,paste,collapse=""),levels=levelUM)
	fac <- table(auxi)
	fac0 <- as.vector(fac)
	names(fac0) <- names(fac)
	rarelevel <- NULL
	commonlevel <- names(fac)
	if(!is.null(rare)){
		prare <- sum(fac)*rare
		rarelevel <- names(fac)[fac <= prare]
		names(fac)[fac <= prare] <- rep("rare",sum(fac <= prare))
		fac <- tapply(fac,names(fac),sum)
		commonlevel <- names(fac)[names(fac)!="rare"]
		fac <- c(fac[commonlevel],fac["rare"])
	}else{
		fac <- as.vector(fac)
		names(fac) <- names(fac0)
	}
	alpha1 <- rep(1,length(fac))
	names(alpha1) <- names(fac)
	res <- list()
	res$model <- .MCmultinomdirichlet(fac,alpha1,mc=mc)
	res$variant0 <- fac0
	res$variant1 <- fac
	res$rare <- rare
	res$rarelevel <- rarelevel
	res$commonlevel <- commonlevel
	res$xold <- x
	if(!is.null(rare)){
		res$xnew <- c(commonlevel,rep("rare",length(rarelevel)))[match(auxi,c(commonlevel,rarelevel))]
	}else{
		res$xnew <- as.vector(auxi)
	}
	names(res$xnew) <- rownames(x)
	res$call <- match.call()
	class(res) <- c("combiUHM",class(res))
	res 
}
print.combiUHM <-  function(x,...){
	if (!inherits(x, "combiUHM")) 
      stop("Object of type 'combiUHM' expected")
	cat("Combination of CpG-loci (U/H/M)\n")
	cat("class: ")
	cat(class(x))
	cat("\n$call: ")
	print(x$call)
	cat("\nCommon methylation variants:\n")
	print(x$commonlevel)
	cat("\nRare methylation variants <= ",x$rare,"\n",sep="")
	cat("\nObserved proportion:\n")
	print(x$variant1)
	cat("\nEstimation of SD and Confidence Intervals:\n")
	print(summary(x$model,...))
}
plot.combiUHM <- function(x,cex.label=0.75,main=NULL,add.lines=TRUE,...){
  if (!inherits(x, "combiUHM")) 
      stop("Object of type 'combiUHM' expected")
  if(is.null(main))
    main <- "Estimation of Methylation Variant distributions"
  sx <- summary(x$model,...)
  obs <- x$variant1
  obs <- obs/sum(obs)
  pred <- sx$statistics[,"Mean"]
  qths <- sx$quantiles
  xx <- 1:length(obs)
  plot(0,0,type="n",panel.first=c(abline(h=xx,col="grey",lty=3)),
       ylim=c(1,length(xx)+1),xlim=c(min(qths[,1]),max(qths[,5])),
       ylab="",xlab="proportion",axes=FALSE,main=main)
  axis(1)
  axis(2,at=xx,labels=names(obs),las=1,cex.axis=cex.label)
  box()
  segments(qths[,1],xx,qths[,5],xx,col="black")
  if(add.lines){
	segments(pred[-1],xx[-1],pred[-length(xx)],xx[-length(xx)],col="black",lty=3) 
	segments(obs[-1],xx[-1],obs[-length(xx)],xx[-length(xx)],col="black",lty=2) 
	}
  points(pred,xx,pch=19)
  points(obs,xx,pch=21,bg="white")  
  legend("topright",c("Obs","Exp","CI"),pch=c(21,19,NA),lty=c(NA,NA,1),ncol=3)
}