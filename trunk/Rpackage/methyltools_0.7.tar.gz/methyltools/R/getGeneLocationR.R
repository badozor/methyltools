# add hg38
getGeneLocationR2 <- function(genelist,group=TRUE,orderby="genename",onlychr=FALSE,...){
  require(Homo.sapiens)
  txsByGene <- transcriptsBy(TxDb.Hsapiens.UCSC.hg19.knownGene, 'gene')
  names(txsByGene) <- mget(names(txsByGene),org.Hs.egSYMBOL, ifnotfound=NA)
  descgenes <- as.data.frame(txsByGene[genelist])
  descgenes <- descgenes[,c("group_name","seqnames","start","end","strand")]
  colnames(descgenes) <- c("genename","chrom","txstart","txend","strand")
  descgenes[,"genename"] <- as.character(descgenes[,"genename"])
  descgenes[,"chrom"] <- as.character(descgenes[,"chrom"])
  descgenes[,"txstart"] <- as.numeric(descgenes[,"txstart"])
  descgenes[,"txend"] <- as.numeric(descgenes[,"txend"])
  descgenes[,"strand"] <- as.character(descgenes[,"strand"])
  if(!is.null(orderby))
    descgenes <- descgenes[order(descgenes[,orderby]),]
  if(group){
    w1 <- aggregate(x = descgenes[,-c(4)], by = list(descgenes$genename, descgenes$chrom), FUN = "min")
    w2 <- aggregate(x = descgenes[,-c(3)], by = list(descgenes$genename, descgenes$chrom), FUN = "max")
    w1$nom1 <- paste(w1[,1],w1[,2],sep=".")
    w2$nom2 <- paste(w2[,1],w2[,2],sep=".")
    descgenes <- merge(w1[,c("nom1","genename","chrom","txstart")],w2[,c("nom2","txend","strand")],by.x="nom1",by.y="nom2",all=TRUE)[,-1]
  }
  if(onlychr){
    descgenes <- descgenes[-(grep("_",descgenes$chrom)),]
  }
  if(!any(duplicated(descgenes$genename)))
    rownames(descgenes) <- descgenes$genename
  class(descgenes) <- c("geneloc",class(descgenes))
  return(descgenes)
}
getGeneLocationR <- function(genelist,group=TRUE,orderby="genename",...){
	require(org.Hs.eg.db)
	require(TxDb.Hsapiens.UCSC.hg19.knownGene)
	hsdb <- org.Hs.eg.db
	txdb <- TxDb.Hsapiens.UCSC.hg19.knownGene
	geneid <- suppressWarnings(AnnotationDbi:::select(hsdb, keys=genelist, keytype="SYMBOL",columns=c("UCSCKG","ENTREZID")))
	rownames(geneid) <- NULL
	descgenes <- suppressWarnings(AnnotationDbi:::select(txdb,keys=geneid[,2],columns=c("GENEID","TXCHROM","TXSTART","TXEND","TXSTRAND"),keytype="TXNAME"))
	descgenes <- cbind(geneid,descgenes)
	descgenes <- descgenes[,c("SYMBOL","TXCHROM","TXSTART","TXEND","TXSTRAND")]
	colnames(descgenes) <- c("genename","chrom","txstart","txend","strand")
	if(!is.null(orderby))
		descgenes <- descgenes[order(descgenes[,orderby]),]
	if(group){
		w1 <- aggregate(x = descgenes[,-c(4)], by = list(descgenes$genename, descgenes$chrom), FUN = "min")
		w2 <- aggregate(x = descgenes[,-c(3)], by = list(descgenes$genename, descgenes$chrom), FUN = "max")
		w1$nom1 <- paste(w1[,1],w1[,2],sep=".")
		w2$nom2 <- paste(w2[,1],w2[,2],sep=".")
		descgenes <- merge(w1[,c("nom1","genename","chrom","txstart")],w2[,c("nom2","txend","strand")],by.x="nom1",by.y="nom2",all=TRUE)[,-1]
	}
	class(descgenes) <- c("geneloc",class(descgenes))
	return(descgenes)
}
getGeneInfoR <- function(genelist,orderby="symbol",na.rm = TRUE,exon=TRUE,cds=TRUE,tx=TRUE,ucsckg=TRUE,...){
	require(org.Hs.eg.db)
	require(TxDb.Hsapiens.UCSC.hg19.knownGene)
	hsdb <- org.Hs.eg.db
	txdb <- TxDb.Hsapiens.UCSC.hg19.knownGene
	genelist <- toupper(genelist)
	if(na.rm){
		geneid <- suppressWarnings(na.omit(AnnotationDbi:::select(hsdb, keys=genelist, keytype="SYMBOL",columns=c("UCSCKG","ENTREZID"))))
	}else{
		geneid <- suppressWarnings(AnnotationDbi:::select(hsdb, keys=genelist, keytype="SYMBOL",columns=c("UCSCKG","ENTREZID")))
	}
	descgenes <- suppressWarnings(AnnotationDbi:::select(txdb,keys=geneid[,"UCSCKG"],columns=columns(txdb),keytype="TXNAME"))
	rownames(geneid) <- geneid[,"UCSCKG"]
	geneid <- geneid[descgenes$TXNAME,]
	rownames(geneid) <- NULL
	descgenes <- cbind(geneid,descgenes)
	colnames(descgenes) <- tolower(colnames(descgenes))
	rownames(descgenes) <- NULL
	if(!exon)
		descgenes <- unique(descgenes[,-grep("exon",colnames(descgenes))])
	if(!tx)
		descgenes <- unique(descgenes[,-grep("tx",colnames(descgenes))])
	if(!cds)
		descgenes <- unique(descgenes[,-grep("cds",colnames(descgenes))])
	if(!ucsckg)
		descgenes <- unique(descgenes[,-c(grep("ucsckg",colnames(descgenes)),grep("txname",colnames(descgenes)))])
	if(!is.null(orderby))
		descgenes <- descgenes[order(descgenes[,orderby]),]
	class(descgenes) <- c("geneloc",class(descgenes))
	return(descgenes)
}
getVariantInfoR <- function(chrom,start,end=start,label=NULL,winsize=0,verbose=FALSE,...){
# http://adairama.wordpress.com/2013/02/15/functionally-annotate-snps-and-indels-in-bioconductor/
	require(GenomicRanges)
	require(VariantAnnotation)
	require(TxDb.Hsapiens.UCSC.hg19.knownGene)
	require(org.Hs.eg.db) 
	txdb <- TxDb.Hsapiens.UCSC.hg19.knownGene
	if(is.null(label)){
		label <- paste("variant",1:length(chrom),sep="")
	}
	start <- start-winsize
	end <- end+winsize
	# target
	target <- GRanges(seqnames=Rle(chrom),ranges=IRanges(start, end,names=label),strand=Rle(strand("*")))
	# query
	loc <- suppressWarnings(locateVariants(target,txdb,AllVariants()))
	names(loc) <- NULL
	out <- as.data.frame(loc)
	out$names <- names(target)[out$QUERYID]
	out <- out[,c("names", "seqnames", "start", "end", "LOCATION", "GENEID", "PRECEDEID", "FOLLOWID")]
	out <- unique(out)
	# symbol
	Symbol2id <- as.list(org.Hs.egSYMBOL2EG)
	id2Symbol <- rep(names(Symbol2id),sapply(Symbol2id,length))
	names(id2Symbol) <- unlist(Symbol2id)
	x <- unique(with(out,c(levels(GENEID),levels(PRECEDEID),levels(FOLLOWID))))
	if(verbose)
		table(x %in% names(id2Symbol)) # good, all found
	out$GENESYMBOL <- id2Symbol[ as.character(out$GENEID)]
	out$PRECEDESYMBOL <- id2Symbol[ as.character(out$PRECEDEID)]
	out$FOLLOWSYMBOL <- id2Symbol[ as.character(out$FOLLOWID)]
	out
}
variant.control <- function(label="rownames",chrom="chrom",start="start",end=start){
	list(label = label, chrom=chrom, start=start,end=end)
}
getVariantInfoR.df <- function(df,control=list(),winsize=0,verbose=FALSE,...){
	if (!is.data.frame(df)) 
		stop("data.frame expected")
	control <- do.call("variant.control", control)		
	if(control$label=="rownames"){
		label <- rownames(df)	
	}else{
		label <- as.character(df[,control$label])
	}	
	chrom <- as.character(df[,control$chrom])
	start <- df[,control$start]
	end <- df[,control$end]
	out <- getVariantInfoR(chrom,start,end,label,winsize=winsize,verbose=verbose,...)
	attr(out,"control") <- control
	out
}


