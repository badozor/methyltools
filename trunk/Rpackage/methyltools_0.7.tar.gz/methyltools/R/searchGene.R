searchGene <- function(x,gene,sep=";",type="logical"){
  if(type=="numeric"){
    res <- grep(paste("^",toupper(gene),"$|^",toupper(gene),sep,"|",sep,toupper(gene),"$|",sep,toupper(gene),sep,sep=""),toupper(x))    
  }else if(type=="value"){
    res <- grep(paste("^",toupper(gene),"$|^",toupper(gene),sep,"|",sep,toupper(gene),"$|",sep,toupper(gene),sep,sep=""),toupper(x),value=TRUE)    
  }else if(type=="logical"){
    res <- grepl(paste("^",toupper(gene),"$|^",toupper(gene),sep,"|",sep,toupper(gene),"$|",sep,toupper(gene),sep,sep=""),toupper(x))
  }else stop("non convenient type!")
  res
}

