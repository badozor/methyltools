entropy.index <- function(x,standard=FALSE,...){
# cf hataway 1992
	if(inherits(x,"data.frame")){
		x1 <- 1/ncol(x)
		x <- apply(x,1,function(z) z/sum(z))
		x <- as.data.frame(t(x))
	}else{
		x1 <- 1/length(x)
		x <- x/sum(x)
	}
	w <- as.vector(as.matrix(x))
	w1 <- rep(x1,length(w))
	w <- -sum(w*log(ifelse(w==0,1,w)))
	if(standard)
		w <- w/(-sum(w1*log(ifelse(w1==0,1,w1))))
	return(w)
}

