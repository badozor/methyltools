cghCall2GR <-
function(x,chrom,strand="+",...){
	if(!inherits(x,"cghCall"))
		stop("non convenient argument!")
	Chromo <- chromosomes(x)
	selectchr <- Chromo==chrom
	IDprobe <- as.character(featureNames(x))[selectchr]
	BPstart <- bpstart(calls)[selectchr]
	BPend <- bpend(calls)[selectchr]
	Chromo <- Chromo[selectchr]
	GRanges(seqnames=Rle(Chromo),ranges=IRanges(names=IDprobe,start=BPstart,end=BPend),strand=Rle(rep(strand,length(IDprobe))),...)
}