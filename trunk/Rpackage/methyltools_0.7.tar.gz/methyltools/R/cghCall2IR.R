cghCall2IR <-
function(x,chrom,...){
	if(!inherits(x,"cghCall"))
		stop("non convenient argument!")
	Chromo <- chromosomes(x)
	selectchr <- Chromo==chrom
	IDprobe <- as.character(featureNames(x))[selectchr]
	BPstart <- bpstart(calls)[selectchr]
	BPend <- bpend(calls)[selectchr]
	res <- IRanges(names=IDprobe,start=BPstart,end=BPend,...)
	attr(res,"chrom") <- chrom
	return(res)
}
