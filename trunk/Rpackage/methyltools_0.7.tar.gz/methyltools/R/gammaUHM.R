gammaUHM <- function(df,lim=c(0.95,0.95),cpus=3,...){
	categUHM <- function(prob,lim){
		x <- c(prob[1]>=lim[1],prob[2]>=lim[2])
		if(x[1] & !x[2]){
			z <- "U"	
		}else if(!x[1] & x[2]){
			z <- "M"		
		}else if(!x[1] & !x[2]){
			z <- "H"
		}else if(x[1] & x[2]){
			z <- NA
		}
		z
	}
	if(cpus>1){
		sfStop()
		sfInit(parallel=TRUE, cpus=cpus)
		sfLibrary("lumi")
		sfExport("df")
		res <- sfApply(df,2,gammaFitEM,...)
		sfStop()
		# posterior and categorization 	
		sfInit( parallel=TRUE, cpus=cpus)
		sfExport("categUHM")
		sfExport("res")
		sfExport("lim")
		for(i in 1:ncol(df)){
			res[[i]]$cluster <- unlist(sfApply(res[[i]]$probability,1,categUHM,lim=lim,...))
		}
		sfStop()
	}else{	
		res <- apply(df,2,gammaFitEM)
		for(i in 1:ncol(df)){
			res[[i]]$cluster <- unlist(apply(res[[i]]$probability,1,categUHM,lim=lim))
		}		
	}
	return(res)	
}