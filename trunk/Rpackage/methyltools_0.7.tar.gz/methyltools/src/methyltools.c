/* =============================================================================
 Title: methyltools.c
 Description: C engine for pls computation based on NIPAS algorithm
 Author: Pierre BADY <pierre.bady@free.fr>
 Date: 2014-05-30
 Revision: 2014-05-30 modified by pbady
 Version: 0.1
 Comments: RAS
 License: GPL version 2 or newer
 Copyright (C) 2008-2014  Pierre BADY

 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License
 as published by the Free Software Foundation; either version 2
 of the License, or (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.
============================================================================= */

# include "methyltools.h"

/* new function: 07/25/08 10:33:43 */
void AUC(int* length, double* x, double* y, double* res){
  int len,i;
  double w,a;
  len=*length;
  w = 0.0;
  a = 0.0;
  for(i=0;i< (len-1);i++){
    a=fabs(x[i]-x[i+1])*(y[i]+y[i+1])/2;
    w=w+a;
  }
  *res=w;
}
/* fonction de Daniel Chessel pour l'allocation dynamique de la memoire issue de la librairie ade4 (version 1.4) */
void taballoc (double ***tab, int l1, int c1){
    int i, j;
    if ( (*tab = (double **) calloc(l1+1, sizeof(double *))) != 0) {
        for (i=0;i<=l1;i++) {
            if ( (*(*tab+i)=(double *) calloc(c1+1, sizeof(double))) == 0 ) {
                return;
                for (j=0;j<i;j++) {
                    free(*(*tab+j));
                }
            }
        }
    }
    **(*tab) = l1;
    **(*tab+1) = c1;
}
void freetab (double **tab){
    int i, n;
    n = *(*(tab));
    for (i=0;i<=n;i++) {
            free((char *) *(tab+i) );
    }
    free((char *) tab);
}
void vecalloc (double **vec, int n){
    if ( (*vec = (double *) calloc(n+1, sizeof(double))) != 0) {
        **vec = n;
        return;
    }
    else {
        return;
    }
}
void freevec (double *vec){
    free((char *) vec);
}
void vecallocInt (int **vec, int n){
    if ( (*vec = (int *) calloc(n+1, sizeof(int))) != 0) {
        **vec = n;
        return;
    }
    else {
        return;
    }
}
void freevecInt (int *vec){
    free((char *) vec);
}
/* implementation of the functions for percentiles and detection outliers */
/* 2014-05-30 modified by pbady */
/* percentile for mode 7 in R*/
int compare_doubles (const void *a, const void *b){
	const double *da = (const double *) a;
	const double *db = (const double *) b;
	return (*da > *db) - (*da < *db);
}
void percentile(double *x,int *n, double* prob,double* res){
	int size,lo,hi,i;
	size= *n;
	i =0;
	double index,h,qs;
	double *xx;
	vecalloc(&xx,size);
	for(i=0; i< size; i++)
		xx[i]=x[i];
	index=0.0;
	qs=0.0;
	index = 1+(size-1)*prob[0];
	lo = floor(index);
	hi = ceil(index);
	qsort(xx, size, sizeof(double), compare_doubles);
	qs = xx[lo-1];
	h = (index-lo);
	*res = (1-h)*qs + h*xx[hi-1];
	freevec(xx);
}
/* outlier detection */
void outliers(double *x, int *n, double* coef,double* limit, int* out){
	int i=0;
	double q1,q3,prob1,prob3,iqr;
	q1 =0.0;
	q3 =0.0;
	prob1 =0.25;
	prob3 =0.75;
	percentile(x,n,&prob1,&q1);
	percentile(x,n,&prob3,&q3);
	iqr = q3-q1;
	limit[0] = q1 - (*coef) * iqr;
	limit[1] = q3 + (*coef) * iqr;
	for(i=0;i< (*n);i++){
		if(x[i] >= limit[0] && x[i] <= limit[1]){
			out[i] = 0;
		}else{
			out[i] = 1;
		}
	}
}
/* Max and min after outlier exclusion */
void MaxMinOut(double *x, int *n, double* coef,double* maxmin){
	int i=0;
	double q1,q3,prob1,prob3,iqr;
	double limit[2]={0.0,0.0};
	q1 =0.0;
	q3 =0.0;
	prob1 =0.25;
	prob3 =0.75;
	percentile(x,n,&prob1,&q1);
	percentile(x,n,&prob3,&q3);
	iqr = q3-q1;
	limit[0] = q1 - (*coef) * iqr;
	limit[1] = q3 + (*coef) * iqr;
	maxmin[0] =limit[1];
	maxmin[1] =limit[0];
	for(i=0;i< (*n);i++){
		if(x[i] >= limit[0] && x[i] <= limit[1]){
			maxmin[0] = fmin(x[i],maxmin[0]);
			maxmin[1] = fmax(x[i],maxmin[1]);
		}
	}
}
void MaxMin(double *x, int *n,double* maxmin){
	int i=0;
	maxmin[0] =x[i];
	maxmin[1] =x[i];
	for(i=0;i< (*n);i++){
		maxmin[0] = fmin(x[i],maxmin[0]);
		maxmin[1] = fmax(x[i],maxmin[1]);
		}
}
void SumX(int* n,double* x,double* S){
  int i,nx;
  double w;
  w = 0.0;
  nx = *n;
  for(i=0;i<nx;i++)
  if(R_FINITE(x[i]))
      w +=x[i];
  S[0] = w;
}
void SumX2(int* n,double* x,double* S){
  int i,nx;
  double w;
  w = 0.0;
  nx = *n;
  for(i=0;i<nx;i++)
  if(R_FINITE(x[i]))
      w +=(x[i]*x[i]);
  S[0] = w;
}
void MeanX(int* n, double* x,double* m){
  int i,nx;
  double sx,sw;
  sx = 0.0;
  sw = 0.0;
  nx = *n;
  for(i=0;i<nx;i++){
    if(R_FINITE(x[i]))
      sx += x[i];
      sw += 1;
    }
  m[0] = sx/sw;
}
void VarX(int* n, double* x,double* v){
  int i,nx;
  double sx,sw;
  double m[1]={0.0};
  sx = 0.0;
  sw = 0.0;
  nx = *n;
  MeanX(n,x,m);
  for(i=0;i<nx;i++){
    if(R_FINITE(x[i]))
      sx += (x[i]-(*m))*(x[i]-(*m));
      sw += 1;
    }
  v[0] = sx/sw;
}
/* additional function used in gplsFitter 06/27/09 12:07:19 */
void MeanXwt(int*n, double* x,double* wt,double* m){
  int i,nx;
  double sx,sw;
  sx = 0.0;
  sw = 0.0;
  nx = *n;
  for(i=0;i<nx;i++){
    if(R_FINITE(x[i]) && R_FINITE(wt[i]))
      sx += x[i]*wt[i];
      sw += wt[i];
    }
  m[0] = sx/sw;
}
/* 2010-08-27 by pbady */
void VarXwt(int* n, double* x,double* wt,double* v){
  int i,nx;
  double sx,sw;
  double m[1]={0.0};
  sx = 0.0;
  sw = 0.0;
  nx = *n;
  MeanXwt(n,x,wt,m);
  for(i=0;i<nx;i++){
    if(R_FINITE(x[i]))
      sx += (x[i]-(*m))*(x[i]-(*m))*wt[i];
      sw += wt[i];
    }
  v[0] = sx/sw;
}
void countNonFinite(double *x, int *n,int* res){
	  int i,nx;
	  nx=0;
	  i=0;
	  for(i=0;i<(*n);i++){
	    if(R_FINITE(x[i]))
	    	nx+=1;
		}
	  res[0] = (*n) - nx;
}
void Summary(double *x, int *n,double* res){
	double q1,q2,q3,prob1,prob2,prob3;
	double maxmin[2]={0.0,0.0};
	double mean[1]={0.0};
	double sigma[1]={0.0};
	int nfinite[1]={0};
	q1 = 0.0;
	q2 = 0.0;
	q3 = 0.0;
	prob1 =0.25;
	prob2 =0.5;
	prob3 =0.75;
	percentile(x,n,&prob1,&q1);
	percentile(x,n,&prob2,&q2);
	percentile(x,n,&prob3,&q3);
	MaxMin(x,n,maxmin);
	MeanX(n,x,mean);
	VarX(n,x,sigma);
	res[0] = maxmin[0];
	res[1] = q1;
	res[2] = q2;
	res[3] = q3;
	res[4] = maxmin[1];
	res[5] = mean[0];
	res[6] = sqrt(sigma[0]);
	res[7] = (*n);
	res[8] = nfinite[0];
}
double getBorne(double x,double y,int nx,int ny){
	double lim = NAN;
	if(nx == 0 && ny > 0){
		lim = y;
	}
	if(nx > 0 && ny == 0){
		lim = x;
	}
	if(nx > 0 && ny > 0){
		lim = (x+y)/2;
	}
	return lim;
}
void ScaleX(int* n,int* p, double* X,double* Y){
  int i,j,col,lig;
  double*moy,*var;
  double sum,maxvar;
  sum= 0.0;
  maxvar= 0.0;
  lig=*n;
  col=*p;
  vecalloc(&moy,col);
  vecalloc(&var,col);
  for(j=0;j < col;j++){
    sum=0;
    for(i=0;i< lig;i++)
      sum+= X[i+(lig*j)];
    moy[j] = sum/(lig);
  }
  for(j=0;j < col;j++){
    sum=0;
    for(i=0;i< lig;i++)
      sum+= (X[i+(lig*j)]-moy[j])*(X[i+(lig*j)]-moy[j]);
    var[j] = sum/(lig);
  }
  for(j=0;j < col;j++)
    if(maxvar <= var[j])
      maxvar = var[j];
  for(j=0;j < col;j++)
    if(var[j] <= (0.0000001 *maxvar))
      var[j] = 1;
  for(j=0;j < col;j++)
    for(i=0;i< lig;i++)
      Y[i+(lig*j)]=(X[i+(lig*j)]-moy[j])/sqrt(var[j]);
  freevec(moy);
  freevec(var);
}
void ScaleXwt(int* n,int* p, double* X,double* wt, double* Y){
  int i,j,col,lig;
  double*moy,*var;
  double sum,sumw,maxvar;
  sum= 0.0;
  sumw= 0.0;
  maxvar=0.0;
  lig=*n;
  col=*p;
  vecalloc(&moy,col);
  vecalloc(&var,col);
  for(i=0;i< lig;i++)
      sumw+= wt[i];
  for(j=0;j < col;j++){
    sum=0;
    for(i=0;i< lig;i++)
      sum+= X[i+(lig*j)]*wt[i];
    moy[j] = sum/sumw;
  }
  for(j=0;j < col;j++){
    sum=0;
    for(i=0;i< lig;i++)
      sum+= (X[i+(lig*j)]-moy[j])*(X[i+(lig*j)]-moy[j])*wt[i];
    var[j] = sum/sumw;
  }
  for(j=0;j < col;j++)
    if(maxvar <= var[j])
      maxvar = var[j];
  for(j=0;j < col;j++)
    if(var[j] <= (0.0000001 *maxvar))
      var[j] = 1;
  for(j=0;j < col;j++)
    for(i=0;i< lig;i++)
      Y[i+(lig*j)]=(X[i+(lig*j)]-moy[j])/sqrt(var[j]);
  freevec(moy);
  freevec(var);
}
void SumProdXYwt(int* n,double* x,double* y,double* wt,double* S){
  int i,nx;
  double w;
  w = 0.0;
  nx = *n;
  for(i=0;i<nx;i++)
  if(R_FINITE(x[i]) && R_FINITE(y[i])&& R_FINITE(wt[i]))
      w +=x[i]*y[i]*wt[i];
  S[0] = w;
}
/* get the limit for 4 class (deletion, none, gain, amplification)*/
void getLimit4mixOut(double *seg, double *call,int *n,double *limit,int *vecsize){
	int i,size,ndel,ngain,namp,nnone,k1,k2,k3,k4;
	double* gain;
	double* amp;
	double* del;
	double* none;
	double limitgain[2]={0.0,0.0};
	double limitamp[2]={0.0,0.0};
	double limitdel[2]={0.0,0.0};
	double limitnone[2]={0.0,0.0};
	double coef;
	i=0;
	size=*n;
	ngain=0;namp=0;ndel=0;nnone=0;
	coef=1.5;
	for(i=0;i < size; i++){
		if(call[i]==1)
			ngain +=1;
		else if(call[i]==2)
			namp +=1;
		else if(call[i]==-1||call[i]==-2)
			ndel +=1;
		else nnone +=1;
	}
	for(i=0;i < 4; i++)	vecsize[i]=0;
	vecalloc(&del,ndel);
	vecalloc(&gain,ngain);
	vecalloc(&amp,namp);
	vecalloc(&none,nnone);
	k1=0;k2=0;k3=0;k4=0;
	for(i=0;i < size; i++){
		if(call[i]==1){
			gain[k1]=seg[i];
			k1 = k1+1;
		}else if(call[i]==2){
			amp[k2]=seg[i];
			k2 = k2+1;
		}else if(call[i]==-1||call[i]==-2){
			del[k3]=seg[i];
			k3 = k3+1;
		}else{
			none[k4]=seg[i];
			k4 = k4+1;
		}
	}
	MaxMinOut(gain,&ngain, &coef,limitgain);
	MaxMinOut(del,&ndel, &coef,limitdel);
	MaxMinOut(amp,&namp, &coef,limitamp);
	MaxMinOut(none,&nnone, &coef,limitnone);
	limit[0] = getBorne(limitdel[1],limitnone[0],ndel,nnone);
	limit[1] = getBorne(limitnone[1],limitgain[0],nnone,ngain);
	limit[2] = getBorne(limitgain[1],limitamp[0],ngain,namp);
	freevec(gain);
	freevec(amp);
	freevec(none);
	freevec(del);
}
void getLimit4mix(double *seg, double *call,int *n,double *limit,int *vecsize){
	int i,size,ndel,ngain,namp,nnone,k1,k2,k3,k4;
	double* gain;
	double* amp;
	double* del;
	double* none;
	double limitgain[2]={0.0,0.0};
	double limitamp[2]={0.0,0.0};
	double limitdel[2]={0.0,0.0};
	double limitnone[2]={0.0,0.0};
	i=0;
	size=*n;
	ngain=0;namp=0;ndel=0;nnone=0;
	for(i=0;i < size; i++){
		if(call[i]==1)
			ngain +=1;
		else if(call[i]==2)
			namp +=1;
		else if(call[i]==-1||call[i]==-2)
			ndel +=1;
		else nnone +=1;
	}
	for(i=0;i < 4; i++)	vecsize[i]=0;
	vecalloc(&del,ndel);
	vecalloc(&gain,ngain);
	vecalloc(&amp,namp);
	vecalloc(&none,nnone);
	k1=0;k2=0;k3=0;k4=0;
	for(i=0;i < size; i++){
		if(call[i]==1){
			gain[k1]=seg[i];
			k1 = k1+1;
		}else if(call[i]==2){
			amp[k2]=seg[i];
			k2 = k2+1;
		}else if(call[i]==-1||call[i]==-2){
			del[k3]=seg[i];
			k3 = k3+1;
		}else{
			none[k4]=seg[i];
			k4 = k4+1;
		}
	}
	MaxMin(gain,&ngain,limitgain);
	MaxMin(del,&ndel,limitdel);
	MaxMin(amp,&namp,limitamp);
	MaxMin(none,&nnone,limitnone);
	limit[0] = getBorne(limitdel[1],limitnone[0],ndel,nnone);
	limit[1] = getBorne(limitnone[1],limitgain[0],nnone,ngain);
	limit[2] = getBorne(limitgain[1],limitamp[0],ngain,namp);
	freevec(gain);
	freevec(amp);
	freevec(none);
	freevec(del);
}
/* get the limit for 5 class (double deletion, deletion, none, gain, amplification)*/
void getLimit5mixOut(double *seg, double *call,int *n,double *limit,int *vecsize){
	int i,size,ndel,ngain,namp,nnone,nddel,k1,k2,k3,k4,k5;
	double* gain;
	double* amp;
	double* del;
	double* ddel;
	double* none;
	double limitgain[2]={0.0,0.0};
	double limitamp[2]={0.0,0.0};
	double limitdel[2]={0.0,0.0};
	double limitddel[2]={0.0,0.0};
	double limitnone[2]={0.0,0.0};
	double coef;
	i=0;
	size=*n;
	ngain=0;namp=0;ndel=0;nnone=0;nddel=0;
	coef=1.5;
	for(i=0;i < size; i++){
		if(call[i]==1)
			ngain +=1;
		else if(call[i]==2)
			namp +=1;
		else if (call[i]==-1)
			ndel +=1;
		else if (call[i]==-2)
			nddel +=1;
		else nnone +=1;
	}
	for(i=0;i < 5; i++)	vecsize[i]=0;
	vecalloc(&del,ndel);
	vecalloc(&gain,ngain);
	vecalloc(&amp,namp);
	vecalloc(&none,nnone);
	vecalloc(&ddel,nddel);
	k1=0;k2=0;k3=0;k4=0;k5=0;
	for(i=0;i < size; i++){
		if(call[i]==1){
			gain[k1]=seg[i];
			k1 = k1+1;
		}else if(call[i]==2){
			amp[k2]=seg[i];
			k2 = k2+1;
		}else if (call[i]==-1){
			del[k3]=seg[i];
			k3 = k3+1;
		}else if (call[i]==-2){
			ddel[k5]=seg[i];
			k5 = k5+1;
		}else{
			none[k4]=seg[i];
			k4 = k4+1;
		}
	}
	MaxMinOut(gain,&ngain, &coef,limitgain);
	MaxMinOut(del,&ndel, &coef,limitdel);
	MaxMinOut(amp,&namp, &coef,limitamp);
	MaxMinOut(none,&nnone, &coef,limitnone);
	MaxMinOut(ddel,&nddel, &coef,limitddel);
	limit[0] = getBorne(limitddel[1],limitdel[0],nddel,ndel);
	limit[1] = getBorne(limitdel[1],limitnone[0],ndel,nnone);
	limit[2] = getBorne(limitnone[1],limitgain[0],nnone,ngain);
	limit[3] = getBorne(limitgain[1],limitamp[0],ngain,namp);
	freevec(gain);
	freevec(amp);
	freevec(none);
	freevec(del);
	freevec(ddel);
}
void getLimit5mix(double *seg, double *call,int *n,double *limit,int *vecsize){
	int i,size,ndel,ngain,namp,nnone,nddel,k1,k2,k3,k4,k5;
	double* gain;
	double* amp;
	double* del;
	double* ddel;
	double* none;
	double limitgain[2]={0.0,0.0};
	double limitamp[2]={0.0,0.0};
	double limitdel[2]={0.0,0.0};
	double limitddel[2]={0.0,0.0};
	double limitnone[2]={0.0,0.0};
	i=0;
	size=*n;
	ngain=0;namp=0;ndel=0;nnone=0;nddel=0;
	for(i=0;i < size; i++){
		if(call[i]==1)
			ngain +=1;
		else if(call[i]==2)
			namp +=1;
		else if (call[i]==-1)
			ndel +=1;
		else if (call[i]==-2)
			nddel +=1;
		else nnone +=1;
	}
	for(i=0;i < 5; i++)	vecsize[i]=0;
	vecalloc(&del,ndel);
	vecalloc(&gain,ngain);
	vecalloc(&amp,namp);
	vecalloc(&none,nnone);
	vecalloc(&ddel,nddel);
	k1=0;k2=0;k3=0;k4=0;k5=0;
	for(i=0;i < size; i++){
		if(call[i]==1){
			gain[k1]=seg[i];
			k1 = k1+1;
		}else if(call[i]==2){
			amp[k2]=seg[i];
			k2 = k2+1;
		}else if (call[i]==-1){
			del[k3]=seg[i];
			k3 = k3+1;
		}else if (call[i]==-2){
			ddel[k5]=seg[i];
			k5 = k5+1;
		}else{
			none[k4]=seg[i];
			k4 = k4+1;
		}
	}
	MaxMin(gain,&ngain,limitgain);
	MaxMin(del,&ndel,limitdel);
	MaxMin(amp,&namp,limitamp);
	MaxMin(none,&nnone,limitnone);
	MaxMin(ddel,&nddel,limitddel);
	limit[0] = getBorne(limitddel[1],limitdel[0],nddel,ndel);
	limit[1] = getBorne(limitdel[1],limitnone[0],ndel,nnone);
	limit[2] = getBorne(limitnone[1],limitgain[0],nnone,ngain);
	limit[3] = getBorne(limitgain[1],limitamp[0],ngain,namp);
	freevec(gain);
	freevec(amp);
	freevec(none);
	freevec(del);
	freevec(ddel);
}
/* get the limit for 3 class (deletion, none, gain) */
void getLimit3mixOut(double *seg, double *call,int *n,double *limit,int *vecsize){
	int i,size,ndel,ngain,nnone,k1,k2,k3;
	double* gain;
	double* del;
	double* none;
	double limitgain[2]={0.0,0.0};
	double limitdel[2]={0.0,0.0};
	double limitnone[2]={0.0,0.0};
	double coef;
	i=0;
	size=*n;
	ngain=0;ndel=0;nnone=0;
	coef=1.5;
	for(i=0;i < size; i++){
		if(call[i]==1||call[i]==2)
			ngain +=1;
		else if(call[i]==-1||call[i]==-2)
			ndel +=1;
		else nnone +=1;
	}
	for(i=0;i < 3; i++)	vecsize[i]=0;
	vecalloc(&del,ndel);
	vecalloc(&gain,ngain);
	vecalloc(&none,nnone);
	k1=0;k2=0;k3=0;
	for(i=0;i < size; i++){
		if(call[i]==1||call[i]==2){
			gain[k1]=seg[i];
			k1 = k1+1;
		}else if(call[i]==-1||call[i]==-2){
			del[k2]=seg[i];
			k2 = k2+1;
		}else{
			none[k3]=seg[i];
			k3 = k3+1;
		}
	}
	MaxMinOut(gain,&ngain, &coef,limitgain);
	MaxMinOut(del,&ndel, &coef,limitdel);
	MaxMinOut(none,&nnone, &coef,limitnone);
	limit[0] = getBorne(limitdel[1],limitnone[0],ndel,nnone);
	limit[1] = getBorne(limitnone[1],limitgain[0],nnone,ngain);
	freevec(gain);
	freevec(none);
	freevec(del);
}
void getLimit3mix(double *seg, double *call,int *n,double *limit,int *vecsize){
	int i,size,ndel,ngain,nnone,k1,k2,k3;
	double* gain;
	double* del;
	double* none;
	double limitgain[2]={0.0,0.0};
	double limitdel[2]={0.0,0.0};
	double limitnone[2]={0.0,0.0};
	i=0;
	size=*n;
	ngain=0;ndel=0;nnone=0;
	for(i=0;i < size; i++){
		if(call[i]==1||call[i]==2)
			ngain +=1;
		else if(call[i]==-1||call[i]==-2)
			ndel +=1;
		else nnone +=1;
	}
	for(i=0;i < 3; i++)	vecsize[i]=0;
	vecalloc(&del,ndel);
	vecalloc(&gain,ngain);
	vecalloc(&none,nnone);
	k1=0;k2=0;k3=0;
	for(i=0;i < size; i++){
		if(call[i]==1||call[i]==2){
			gain[k1]=seg[i];
			k1 = k1+1;
		}else if(call[i]==-1||call[i]==-2){
			del[k2]=seg[i];
			k2 = k2+1;
		}else{
			none[k3]=seg[i];
			k3 = k3+1;
		}
	}
	MaxMin(gain,&ngain,limitgain);
	MaxMin(del,&ndel,limitdel);
	MaxMin(none,&nnone,limitnone);
	limit[0] = getBorne(limitdel[1],limitnone[0],ndel,nnone);
	limit[1] = getBorne(limitnone[1],limitgain[0],nnone,ngain);
	freevec(gain);
	freevec(none);
	freevec(del);
}
