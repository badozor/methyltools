# updated 2015-03-17
.phypertest <- function(selected,pathway){
	w <- table(pathway=factor(pathway,levels=c(1,0)),selected=factor(selected,levels=c(1,0)))
	# p <-  phyper(w[1,1]-1,w[1,1]+w[1,2],w[2,1]+w[2,2],w[1,1]+w[2,1],lower.tail=FALSE)
	auxi <- unlist(fisher.test(w,alternative="greater")[c("estimate","p.value")])
	names(auxi) <- c("oddsratio","p.raw")
	c(n=sum(w),in1=w[1,1],in0=w[1,2],out1=w[2,1],out0=w[2,2],auxi)
}
pathway.test <- function(DEgene,pathway,p.method="bonferroni",...){
  res <- lapply(pathway,function(x) .phypertest(DEgene,as.numeric(is.element(names(DEgene),x))))
  res <- as.data.frame(do.call("rbind",res))
  rownames(res) <- names(pathway)
  res$p.adj <- p.adjust(res$p.raw,method=p.method)
  res
}
# multicore version
pathway.mctest <- function(DEgene,pathway,p.method="bonferroni",cpus=2,...){
  require(snowfall)
  # calculation
  if(cpus>1){
      sfStop()
      sfInit(parallel=TRUE, cpus=cpus)
      sfExport("DEgene")
      sfExport("pathway")
      sfExport(".phypertest")
      res <- sfLapply(pathway,function(x) .phypertest(DEgene,as.numeric(is.element(names(DEgene),x))),...)
      sfStop()
    }else{
      res <- lapply(pathway,function(x) .phypertest(DEgene,as.numeric(is.element(names(DEgene),x))))
    }
  res <- as.data.frame(do.call("rbind",res))
  rownames(res) <- names(pathway)
  res$p.adj <- p.adjust(res$p.raw,method=p.method)
  res
}
