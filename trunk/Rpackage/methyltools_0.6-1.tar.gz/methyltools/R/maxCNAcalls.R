maxCNAcalls <- function(X,chrom, start,end,winsize=0,info="region",mode=NULL,nclass=5,...){
	if(!inherits(X,"cghCall"))
		stop("non convenient argument!")
	if(nclass==3){
		cnalabels <- c("d","n","g")
	}else if(nclass==4){
		cnalabels <- c("d","n","g","a")		
	}else if(nclass==5){
		cnalabels <- c("dd","d","n","g","a")		
	}else stop("non convenient number of class!")
	auxi <- extractCGH.default(X,chr=chrom,start=start,end=end,winsize=winsize,info=info,mode=mode)
	res <- list()
	if(dim(auxi)[1] < 1){
		res$cna <- rep(NA,dim(auxi)[2])
	}else{
		callsInf <- calls(auxi)
		w <- apply(callsInf,2,function(x) table(.cna2factor(x,nclass=nclass)))
		res$cna <- unlist(apply(w,2,function(x) cnalabels[which.max(x)]))
		res$entropy <- unlist(apply(w,2,entropy.index,standard=FALSE))
	}
	res$marker <- dim(auxi)[1]
	res$summary <- table(res$cna)
	res$loc <- list(chr=chrom,start=start,end=end)
	res$info <- info
	res$n <- length(res$cna)
	res$maxentropy <- log(nclass)
	res$efficiency <- res$entropy/res$maxentropy
	res$winsize <- winsize
	res$call <- match.call()
	class(res) <- c("CNAcalls",class(res))
	return(res)
}
maxCNAcalls.chr <- function(X,chrom,nclass=5,...){
	if(!inherits(X,"cghCall"))
		stop("non convenient argument!")
	if(nclass==3){
		cnalabels <- c("d","n","g")
	}else if(nclass==4){
		cnalabels <- c("d","n","g","a")		
	}else if(nclass==5){
		cnalabels <- c("dd","d","n","g","a")		
	}else stop("non convenient number of class!")
	if(is.numeric(chrom))
		chrom <- paste("chr",chrom,sep="")
	chromInf <- paste("chr",as.character(chromosomes(X)),sep="")
	IDprobeInf <- as.character(featureNames(X))
	callsInf <- calls(X)
	selectx <- chromInf == chrom
	res <- list()
	if(sum(selectx) < 1){
		res$cna <- rep(NA,ncol(callsInf))
	}else{	
		callsInf <- callsInf[selectx,]
		w <- apply(callsInf,2,function(x) table(.cna2factor(x,nclass=nclass)))
		res$cna <- unlist(apply(w,2,function(x) cnalabels[which.max(x)]))
		res$entropy <- unlist(apply(w,2,entropy.index,standard=FALSE))
	}
	res$marker <- sum(selectx)
	res$summary <- table(res$cna)
	res$loc <- list(chr=chrom,start=NULL,end=NULL)
	res$info <- chrom
	res$n <- length(res$cna)
	res$maxentropy <- log(nclass)
	res$efficiency <- res$entropy/res$maxentropy
	res$winsize <- 0.0
	res$call <- match.call()
	class(res) <- c("CNAcalls",class(res))
	return(res)
}
maxCNAcalls.gene <- function(X,gene,winsize=0,...){
	if(!inherits(X,"cghCall"))
		stop("non convenient argument!")
	gene <- toupper(gene)
	gene1 <- getGeneLocationR(gene)
	res <- maxCNAcalls(X,gene1$chrom,gene1$txstart,gene1$txend,winsize=winsize,info=gene)
	res$call <- match.call()
	return(res)
}
print.CNAcalls <- function(x,...){
	if(!inherits(x,"CNAcalls"))
		stop("non convenient argument!")
	cat("Estimation of CNA based on mixture model (see CGHcall)\n")
	cat("$class: ",class(x),"\n")
	cat("$n: ",x$n,"\n")
	cat("$marker: ",x$marker,"\n")
	cat("$info: ",x$info,"\n")
	cat("$winsize",x$winsize,"\n")
	cat("$location:\n")
	print(unlist(x$loc))
	cat("$summary:")
	print(x$summary)
	cat("$call: ")
	print(x$call)
	cat("\n")
}
