gene2IR <-
function(gene,calls,chrom=NULL,...){
	if(!inherits(gene,"IRanges") & is.character(gene)){
		gene1 <- getGeneLocationR(gene)
		chrom <- gene1$chrom
		chrom <- c(1:24,23,24)[match(chrom,c(paste("chr",1:24,sep=""),"chrX","chrY"))]
		chrom <- as.numeric(chrom)
		if(length(unique(chrom))>1)
			warning("multiple chrosome locations!")
		chrom <- unique(chrom)[1]
		wgene <-geneloc2IR(gene1)
	}else if(inherits(geneloc2IR,"IRanges") & !is.null(chrom)){
		wgene <- gene		
	}else stop("non convenient argument!")
	wcalls <- cghCall2IR(calls,chrom)
	wintersect <- findOverlaps(wcalls,wgene)
	res <- wcalls[attributes(wintersect)$queryHits]
	attr(res,"chrom") <- chrom
	attr(res,"call") <- match.call()
	return(res)
}
