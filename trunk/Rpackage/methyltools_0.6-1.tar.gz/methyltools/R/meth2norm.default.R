meth2norm.default <- function(x,y,method="normalize.quantiles",scaling=FALSE,chemistry=NULL,
	rev=FALSE,verbose=TRUE,add.UM=FALSE,...)
{
	if(ncol(x)!=ncol(y))
		stop("non convenient argument!")
	if(nrow(x)!=nrow(y))
		stop("non convenient argument!")
	if(!all(colnames(x)==colnames(y)))
		stop("non convenient argument!")
	if(!all(rownames(x)==rownames(y)))
		stop("non convenient argument!")
	if(!is.null(method))
		func <- get(method)
	U <- x
	M <- y
	if(is.null(chemistry))
		stop("'chemistry' information is required!")
	samplenames <- colnames(U)
	probenames <- rownames(M)
	if(scaling){
		if(rev){
			U <- apply(U,2, function(x) ifelse(chemistry=="I", x*sd(x[chemistry=="II"])/sd(x[chemistry=="I"]),x))
			M <- apply(M,2, function(x) ifelse(chemistry=="I", x*sd(x[chemistry=="II"])/sd(x[chemistry=="I"]),x))
		}else{
			U <- apply(U,2, function(x) ifelse(chemistry=="II", x*sd(x[chemistry=="I"])/sd(x[chemistry=="II"]),x))
			M <- apply(M,2, function(x) ifelse(chemistry=="II", x*sd(x[chemistry=="I"])/sd(x[chemistry=="II"]),x))
		}
	}
	if(!is.null(method)){
		UM <- cbind(U,M)
		UM <- func(UM,...)
		U <- UM[,1:ncol(U)]
		M <- UM[,(1+ncol(U)):(ncol(M)+ncol(U))]
	}
	T <- U+M
	rownames(U) <- rownames(M) <- rownames(T) <- probenames
	colnames(U) <- colnames(M) <- colnames(T) <- samplenames
	if(add.UM){
		res <- list(T=T,U=U,M=M)		
	}else{
		res <- list(T=T)
	}
	res$colnames <- samplenames
	res$rownames <- probenames
	res$chemistry <- chemistry
	res$call <- match.call()
	return(res)
}