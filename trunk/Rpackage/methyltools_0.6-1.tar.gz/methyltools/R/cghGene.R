cghGene <-
function(gene,calls,...){
	auxi <- gene2IR(gene,calls,...)
	ID <- attributes(auxi)$NAMES 
	calls[ID]
}
