# Revision: Jun 18, 2014 10:03:04 AM
# transform cna into a factor
.cna2factor <- function(x,nclass=5){
	if(nclass==3){
		x <- c(-1,-1,0,1,1)[match(x,c(-2,-1,0,1,2))]
		x <- factor(x,levels=c(-1,0,1),labels=c("d","n","g"))		
	}else if(nclass==4){
		x <- c(-1,-1,0,1,2)[match(x,c(-2,-1,0,1,2))]
		x <- factor(x,levels=c(-1,0,1,2),labels=c("d","n","g","a"))							
	}else if(nclass==5){
		x <- factor(x,levels=c(-2,-1,0,1,2),labels=c("dd","d","n","g","a"))		
	}
	return(x)
}
.filtre <- function(x){
	xout <- boxplot.stats(x)$out
	x[!is.element(x,xout)]
}
.borne <- function(x,y){
	if(length(x)<1){
		lim <- min(y)
	}else if(length(y)<1){
		lim <- max(x)
	}else{
		lim <- (max(x)+min(y))/2
	}
	lim
}
#.getLimitMix4 <- function(x,useout=FALSE,...){
#	if(!inherits(x,"cghCall"))
#		stop("non convenient argument!")
#	wcp <- segmented(x)
#	wcall <- calls(x)
#	func <- function(xcp,xcall,useout=FALSE){
#		if(useout){
#			wnone <- xcp[xcall==0]
#			wdel <- xcp[xcall==-1]
#			wgain <- xcp[xcall==1]
#			wamp <- xcp[xcall==2]			
#		}else{
#			wnone <- .filtre(xcp[xcall==0])
#			wdel <- .filtre(xcp[xcall==-1])
#			wgain <- .filtre(xcp[xcall==1])
#			wamp <- .filtre(xcp[xcall==2])
#		}
#		c("d"=.borne(wdel,wnone),"g"=.borne(wnone,wgain),"a"=.borne(wgain,wamp))
#	}
#	w <- t(sapply(1:ncol(x),function(z) func(wcp[,z],wcall[,z],useout=useout)))
#	rownames(w) <- colnames(x)
#	attr(x,"limitmix") <- w
#	x
#}
.getLimitMixC <- function(x,useout=FALSE,nclass=5,...){
	if(!inherits(x,"cghCall"))
		stop("non convenient argument!")
	wcp <- segmented(x)
	wcall <- calls(x)
	if(useout){
		if(nclass==3){
			func <- function(xcp,xcall){
				limit <- .C("getLimit3mix",as.double(xcp), as.double(xcall),as.integer(length(xcp)),as.double(rep(0.0,2)),as.integer(rep(0,3)),PACKAGE = "methyltools")[[4]]
				c("d"=limit[1],"g"=limit[2])
			}
		}else if(nclass==4){
			func <- function(xcp,xcall){
				limit <- .C("getLimit4mix",as.double(xcp), as.double(xcall),as.integer(length(xcp)),as.double(rep(0.0,3)),as.integer(rep(0,4)),PACKAGE = "methyltools")[[4]]	
				c("d"=limit[1],"g"=limit[2],"a"=limit[3])
				}
		}else if(nclass==5){
			func <- function(xcp,xcall){
				limit <- .C("getLimit5mix",as.double(xcp), as.double(xcall),as.integer(length(xcp)),as.double(rep(0.0,4)),as.integer(rep(0,5)),PACKAGE = "methyltools")[[4]]
				c("dd"=limit[1],"d"=limit[2],"g"=limit[3],"a"=limit[4])
				}
		}
	}else{
		if(nclass==3){
			func <- function(xcp,xcall){
				limit <- .C("getLimit3mixOut",as.double(xcp), as.double(xcall),as.integer(length(xcp)),as.double(rep(0.0,2)),as.integer(rep(0,3)),PACKAGE = "methyltools")[[4]]
				c("d"=limit[1],"g"=limit[2])
			}
		}else if(nclass==4){
			func <- function(xcp,xcall){
				limit <- .C("getLimit4mixOut",as.double(xcp), as.double(xcall),as.integer(length(xcp)),as.double(rep(0.0,3)),as.integer(rep(0,4)),PACKAGE = "methyltools")[[4]]	
				c("d"=limit[1],"g"=limit[2],"a"=limit[3])
			}
		}else if(nclass==5){
			func <- function(xcp,xcall){
				limit <- .C("getLimit5mixOut",as.double(xcp), as.double(xcall),as.integer(length(xcp)),as.double(rep(0.0,4)),as.integer(rep(0,5)),PACKAGE = "methyltools")[[4]]
				c("dd"=limit[1],"d"=limit[2],"g"=limit[3],"a"=limit[4])
			}
		}
	}
	w <- t(sapply(1:ncol(x),function(z) func(wcp[,z],wcall[,z])))
	rownames(w) <- colnames(x)
	attr(x,"limitmix") <- w
	x	
}
.getLimitMix5 <- function(x,useout=FALSE,...){
	if(!inherits(x,"cghCall"))
		stop("non convenient argument!")
	wcp <- CGHbase:::segmented(x)
	wcall <- CGHbase:::calls(x)
	func <- function(xcp,xcall,useout=FALSE){
		if(useout){
			wnone <- xcp[xcall==0]
			wdel <- xcp[xcall==-1]
			wddel <- xcp[xcall==-2]
			wgain <- xcp[xcall==1]
			wamp <- xcp[xcall==2]			
		}else{
			wnone <- .filtre(xcp[xcall==0])
			wdel <- .filtre(xcp[xcall==-1])
			wddel <- .filtre(xcp[xcall==-2])
			wgain <- .filtre(xcp[xcall==1])
			wamp <- .filtre(xcp[xcall==2])
		}
		c("dd"=.borne(wddel,wdel) ,"d"=.borne(wdel,wnone),"g"=.borne(wnone,wgain),"a"=.borne(wgain,wamp))
	}
	w <- t(sapply(1:ncol(x),function(z) func(wcp[,z],wcall[,z],useout=useout)))
	rownames(w) <- colnames(x)
	attr(x,"limitmix") <- w
	x
}
.mixclass <- function(x,xcp,xcall,limit,nclass=5){
	classx <- rep("n",length(x))
	classx[which(x <= limit["d"])] <- "d"
	if(nclass > 4)
		classx[which(x <= limit["dd"])] <- "dd"	
	classx[which(x >= limit["g"])] <- "g"
	if(nclass > 3)
		classx[which(x >= limit["a"])] <- "a"	
	classx
}
