/* =============================================================================
 Title: methyltools.h
 Description: C engine for pls computation based on NIPAS algorithm
 Author: Pierre BADY <pierre.bady@free.fr>
 Date: 2014-05-30
 Revision: 2014-05-30 modified by pbady
 Version: 0.1
 Comments: RAS
 License: GPL version 2 or newer
 Copyright (C) 2008-2014  Pierre BADY

 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License
 as published by the Free Software Foundation; either version 2
 of the License, or (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.
============================================================================= */
/* 2014-05-30 modified by pbady */
# include <stdio.h>
# include <stdlib.h>
# include <math.h>
# include <R.h>
# include <Rdefines.h>
# include <Rmath.h>
# include <Rinternals.h>

/* memory allocation */
void taballoc(double ***tab, int l1, int c1);
void freetab(double **tab);
void vecalloc(double **vec, int n);
void freevec(double *vec);
void vecallocInt(int **vec, int n);
void freevecInt(int *vec);

/* statistics */
void AUC(int* length, double* x, double* y, double* res);
int compare_doubles (const void *a, const void *b);
void percentile(double *x,int *n, double* prob,double* res);
void outliers(double *x, int *n, double* coef,double* limit, int* out);
void MaxMinOut(double *x, int *n, double* coef,double* maxmin);
void MaxMin(double *x, int *n,double* maxmin);
void Summary(double *x, int *n,double* res);
void SumX(int* n,double* x,double* S);
void SumX2(int* n,double* x,double* S);
void MeanX(int* n, double* x,double* m);
void VarX(int* n, double* x,double* v);
void countNonFinite(double *x, int *n,int* res);
void MeanXwt(int*n, double* x,double* wt,double* m);
void VarXwt(int* n, double* x,double* wt,double* v);
void ScaleX(int* n,int* p, double* X,double* Y);
void ScaleXwt(int* n,int* p, double* X,double* wt, double* Y);

/*functions for DNA methylation */
void getLimit4mix(double *seg, double *call,int *n,double *limit,int *vecsize);
void getLimit4mixOut(double *seg, double *call,int *n,double *limit,int *vecsize);
double getBorne(double x,double y,int nx,int ny);
