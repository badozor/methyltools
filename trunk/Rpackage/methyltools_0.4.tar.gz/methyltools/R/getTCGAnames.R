getTCGAnames <-
function(x,rownames=TRUE,...){
	if(is.factor(x))
		x <- as.character(x)
	if(!is.character(x))
		stop("non convenient argument!")
	fdecode <- function(z){
		w <- list(Name=substring(z,1,12),Project=substring(z,1,4),
				CollectionCenter=substring(z,6,7),Patient=substring(z,9,12),
				SampleType=substring(z,14,15),SampleSequence=substring(z,16,16),
				PortionSequence=substring(z,18,19),PortionAnalyte=substring(z,20,20),
				PlateID=substring(z,22,25),DataGeneratingCenter=substring(z,27,28))
		w$type <- c("solid tumor","normal blood","normal tissue","buccal smear","cell line")[match(w$SampleType,c("01","10","11","12","20"))]
		return(unlist(w))
	}
	df <- data.frame(do.call("rbind",lapply(x,fdecode)))
	if(rownames)
		row.names(df) <- x
	return(df)
}
