#------------------------------------------------
# additional and modified functions 
# 2013-0821 modified by pbady
#
# functions based on BMIQ is an intra-sample normalisation procedure, 
# adjusting for the bias in type-2 probe values, using a 3-step 
# procedure published in Teschendorff AE et al 
# "A Beta-Mixture Quantile Normalisation method for correcting probe 
# design bias in Illumina Infinium 450k DNA methylation data", 
# Bioinformatics 2012 Nov 21.
# 2013-10-30 modified by pbady
#-----------------------------------------------------------------------
# require(RPMM)
# blc function come from the R package RPMM
# minor modification of the function blc
# the number of iter and criterion used for convergence evalaution is kept in this version.
# blc function come from the R package RPMM
# minor modification of the function blc
# the number of iter and criterion used for convergence evalaution is kept in this version.
blcmodif <- function (Y, w, maxiter = 25, tol = 1e-06, weights = NULL, verbose = TRUE) 
{
	Ymn <- min(Y[Y > 0], na.rm = TRUE)
	Ymx <- max(Y[Y < 1], na.rm = TRUE)
	Y <- pmax(Y, Ymn/2)
	Y <- pmin(Y, 1 - (1 - Ymx)/2)
	Yobs = !is.na(Y)
	J <- dim(Y)[2]
	K <- dim(w)[2]
	n <- dim(w)[1]
	if (n != dim(Y)[1]) 
		stop("Dimensions of w and Y do not agree")
	if (is.null(weights)) 
		weights <- rep(1, n)
	mu <- a <- b <- matrix(Inf, K, J)
	niter <- 0
	crit <- Inf
	for (i in 1:maxiter) {
		niter <- niter+1
		warn0 <- options()$warn
		options(warn = -1)
		eta <- apply(weights * w, 2, sum)/sum(weights)
		mu0 <- mu
		for (k in 1:K) {
			for (j in 1:J) {
				ab <- betaEst(Y[, j], w[, k], weights)
				a[k, j] <- ab[1]
				b[k, j] <- ab[2]
				mu[k, j] <- ab[1]/sum(ab)
			}
		}
		ww <- array(0, dim = c(n, J, K))
		for (k in 1:K) {
			for (j in 1:J) {
				ww[Yobs[, j], j, k] <- dbeta(Y[Yobs[, j], j], 
						a[k, j], b[k, j], log = TRUE)
			}
		}
		options(warn = warn0)
		w <- apply(ww, c(1, 3), sum, na.rm = TRUE)
		wmax <- apply(w, 1, max)
		for (k in 1:K) w[, k] <- w[, k] - wmax
		w <- t(eta * t(exp(w)))
		like <- apply(w, 1, sum)
		w <- (1/like) * w
		llike <- weights * (log(like) + wmax)
		crit <- max(abs(mu - mu0))
		if (verbose) 
			print(crit)
		if (crit < tol) 
			break
	}
	return(list(a = a, b = b, eta = eta, mu = mu, w = w, llike = sum(llike),crit=crit,niter=niter))
}
beta3mix <- function(x,n=length(x),initial=c(0.2,0.75),niter=25,tol=1e-4,...){
# check data
	x <- as.numeric(x)
	if(min(x)==0){
		x[x==0] <- min(setdiff(x,0));
	}
	if(max(x)==1){
		x[x==1] <- max(setdiff(x,1));
	}
	nclass <- 3
# initial condition
	w0 <- matrix(0,nrow=length(x),ncol=nclass)
	w0[which(x <= initial[1]),1] <- 1
	w0[intersect(which(x > initial[1]),which(x <= initial[2])),2] <- 1
	w0[which(x > initial[2]),3] <- 1
# EM fit based on the function blc from R package RPMM
	idx <- sample(1:length(x),n,replace=FALSE)
	em1 <- blcmodif(matrix(x[idx],ncol=1),w=w0[idx,],maxiter=niter,tol=tol)
# cluster
	class1 <- apply(em1$w,1,which.max)
# limits
	lim1 <- c(mean(c(max(x[idx[class1==1]]),min(x[idx[class1==2]]))),mean(c(max(x[idx[class1==2]]),min(x[idx[class1==3]]))))
# classification of the all values proposition Teschendorff AE et al (2012)
	classall <- rep(2,length(x));
	classall[which(x < lim1[1])] <- 1;
	classall[which(x > lim1[2])] <- 3;
# addition info
	em1$idx <- idx
	em1$subcluster <- class1
	em1$lim <- lim1
	em1$meancluster <- classall
	em1$nclass <- nclass
# posterior probabilities for all data
# conditional log-like
	w <- matrix(0,nrow=length(x),ncol=nclass)
	for(k in 1:nclass){
		w[,k] <- dbeta(x, em1$a[k,1], em1$b[k,1], log=TRUE) 
	}
#	w <- t(em1$eta*t(exp(w)))
	w <- t(apply(w,1,function(z) exp(z - max(z)) * em1$eta))
	wlike <- apply(w,1,sum)
	em1$postw <- w/wlike
	em1$postcluster <- apply(em1$postw,1,which.max)
	em1$call <- match.call()
	names(em1$postcluster) <- names(em1$meancluster) <- names(em1$postw) <- names(x)
	class(em1) <- c("beta3mix")
	return(em1)
}
beta3mix.light <- function(x,n=length(x),initial=c(0.2,0.75),niter=25,tol=1e-4,...){
# check data
	x <- as.numeric(x)
	if(min(x)==0){
		x[x==0] <- min(setdiff(x,0));
	}
	if(max(x)==1){
		x[x==1] <- max(setdiff(x,1));
	}
	nclass <- 3
# initial condition
	w0 <- matrix(0,nrow=length(x),ncol=nclass)
	w0[which(x <= initial[1]),1] <- 1
	w0[intersect(which(x > initial[1]),which(x <= initial[2])),2] <- 1
	w0[which(x > initial[2]),3] <- 1
# EM fit based on the function blc from R package RPMM
	idx <- sample(1:length(x),n,replace=FALSE)
	em1 <- blc(matrix(x[idx],ncol=1),w=w0[idx,],maxiter=niter,tol=tol)
# cluster
	class1 <- apply(em1$w,1,which.max)
# limits
	lim1 <- c(mean(c(max(x[idx[class1==1]]),min(x[idx[class1==2]]))),mean(c(max(x[idx[class1==2]]),min(x[idx[class1==3]]))))
# addition info
	em1$idx <- idx
	em1$subcluster <- class1
	em1$lim <- lim1
	em1$nclass <- nclass
	em1$call <- match.call()
	class(em1) <- c("beta3mix") 
	return(em1)
}
predict.beta3mix <- function(object,data,type="postcluster",encoding=NULL,...){
	if(!is.element(type,c("meancluster","postcluster","postproba")))
		stop("non convenient option!")	
	if(!is.numeric(data))
		stop("non convenient data!")			
	nclass <- object$nclass
	if(is.element(type,c("postcluster","postproba"))){
		# posterior data for all
		# conditional log-like
		w <- matrix(0,nrow=length(data),ncol=nclass)
		for(k in 1:nclass){
			w[,k] <- dbeta(data, object$a[k,1], object$b[k,1], log=TRUE) 
		}
		# w <- t(em1$eta*t(exp(w)))
		w <- t(apply(w,1,function(z) exp(z - max(z)) * object$eta))
		wlike <- apply(w,1,sum)
		pred <- w/wlike
		if(type=="postcluster")
			pred <- unlist(apply(pred,1,which.max))
	}else if(type=="meancluster"){
		lim1 <- object$lim
		# classification of the all values
		pred <- rep(2,length(data));
		pred[which(data < lim1[1])] <- 1;
		pred[which(data > lim1[2])] <- 3;
	}
	
	if(!is.element(type,"postproba") & !is.null(encoding))
		pred <- encoding[match(pred,c(1,2,3))]
	attr(pred,"type") <- type
	return(pred)
}
simulate.beta3mix <- function(object,nsim=1,seed=NULL,...){
	nclass <- object$nclass
	if(!is.null(seed))
		set.seed(seed)
	N <- as.vector(rmultinom(1:nclass,nsim,prob=object$eta));
	vec <- vector();
	for(k in 1:nclass){
		vec <- c(vec,rbeta(N[k],object$a[k,1],object$b[k,1]));
	}
	vec
}
plot.beta3mix <- function(x,data,nsim=10000,col=c("black","green2"),...){
	vec <- simulate(object=x,nsim=nsim,...)
	plot(density(data,from=0,to=1),col=col[1]);
	d1 <- density(vec,from=0,to=1);
	points(d1$x,d1$y,col=col[2],type="l")
	for(k in 1:x$nclass){
		dk <- density(rbeta(nsim,x$a[k,1],x$b[k,1]),from=0,to=1)
		points(dk$x,dk$y*x$eta[k],col=col[2],lty=2,type="l")
	}
	legend(x=0.5,y=3,legend=c("obs","fit"),fill=col,bty="n");
}
print.beta3mix <- function(x,...){
	cat("Mixture Model based on 3 Beta distributions\n")
	cat("\ncall:\n")
	print(x$call)
	cat("\nIteration number:\n")
	print(x$niter)
	cat("\nConvergence value:\n")
	print(x$crit)
	cat("\nparameters:\n")
	w <- data.frame(a=x$a,b=x$b,eta=x$eta)
	rownames(w) <- paste("comp",1:3,sep=".")
	print(w)
}
