mixCNAcalls.gene <- function(X,gene,winsize=0,statistic="mean",useout=FALSE,nclass=5,...){
	if(!inherits(X,"cghCall"))
		stop("non convenient argument!")
	funcstat <- get(statistic)
	auxi <- extractCGH.gene(X,gene,winsize) 
	marker <- dim(auxi)[1]
	loc <- attributes(auxi)$loc[c("chr","start","end")]
	if(useout){
		auxi <- apply(segmented(auxi),2,function(z) funcstat(z))
	}else{
		auxi <- apply(segmented(auxi),2,function(z) funcstat(.filtre(z)))
	}
	wcp <- segmented(X)
	wcall <- calls(X)
	wlimit <- attributes(X)$limitmix
	if(is.null(wlimit)){
		X <- .getLimitMix5(X,useout=useout)
		wlimit <- attributes(X)$limitmix
	}
	res <- list()
	res$cna <- sapply(1:length(auxi),function(z) .mixclass(auxi[z],wcp[,z],wcall[,z],wlimit[z,],nclass=nclass))
	names(res$cna) <- colnames(X)
	res$summary <- table(res$cna)
	res$marker <- marker
	res$n <- dim(X)[2]
	res$obs.seg <- auxi
	res$loc <- loc
	res$info <- gene
	res$winsize <- winsize
	res$useout <- useout
	res$call <- match.call()
	class(res) <- c("mixCNAcalls",class(res))
	return(res)
}
mixCNAcalls <- function(X,chrom, start,end,winsize=0,info="region",statistic="mean",useout=FALSE,nclass=5,...){
	if(!inherits(X,"cghCall"))
		stop("non convenient argument!")
	funcstat <- get(statistic)
	auxi <- extractCGH.default(X,chrom, start,end,winsize,info) 
	marker <- dim(auxi)[1]
	loc <- attributes(auxi)$loc[c("chr","start","end")]
	if(useout){
		auxi <- apply(segmented(auxi),2,function(z) funcstat(z))
	}else{
		auxi <- apply(segmented(auxi),2,function(z) funcstat(.filtre(z)))
	}
	wcp <- segmented(X)
	wcall <- calls(X)
	wlimit <- attributes(X)$limitmix
	if(is.null(wlimit)){
		X <- .getLimitMix5(X,useout=useout)
		wlimit <- attributes(X)$limitmix
	}
	res <- list()
	res$cna <- sapply(1:length(auxi),function(z) .mixclass(auxi[z],wcp[,z],wcall[,z],wlimit[z,],nclass=nclass))
	names(res$cna) <- colnames(X)
	res$summary <- table(res$cna)
	res$marker <- marker
	res$n <- dim(X)[2]
	res$obs.seg <- auxi
	res$loc <- loc
	res$info <- info
	res$winsize <- winsize
	res$useout <- useout
	res$call <- match.call()
	class(res) <- c("mixCNAcalls",class(res))
	return(res)
}
mixCNAcalls.chr <- function(X,chrom,statistic="mean",useout=FALSE,nclass=5,...){
	if(!inherits(X,"cghCall"))
		stop("non convenient argument!")
	funcstat <- get(statistic)
	auxi <- extractCGH.chr(X,chrom) 
	marker <- dim(auxi)[1]
	if(useout){
		auxi <- apply(segmented(auxi),2,function(z) funcstat(z))
	}else{
		auxi <- apply(segmented(auxi),2,function(z) funcstat(.filtre(z)))
	}
	wcp <- segmented(X)
	wcall <- calls(X)
	wlimit <- attributes(X)$limitmix
	if(is.null(wlimit)){
		X <- .getLimitMix5(X,useout=useout)
		wlimit <- attributes(X)$limitmix
	}
	res <- list()
	res$cna <- sapply(1:length(auxi),function(z) .mixclass(auxi[z],wcp[,z],wcall[,z],wlimit[z,],nclass=nclass))
	names(res$cna) <- colnames(X)
	res$summary <- table(res$cna)
	res$marker <- marker
	res$n <- dim(X)[2]
	res$obs.seg <- auxi
	res$loc <- list(chr=chrom,start=NULL,end=NULL)
	res$info <- chrom
	res$winsize <- 0.0
	res$useout <- useout
	res$call <- match.call()
	class(res) <- c("mixCNAcalls",class(res))
	return(res)
}
print.mixCNAcalls <- function(x,...){
	if(!inherits(x,"mixCNAcalls"))
		stop("non convenient argument!")
	cat("Estimation of CNA based on mixture model (see CGHcall)\n")
	cat("$class: ",class(x),"\n")
	cat("$n: ",x$n,"\n")
	cat("$marker: ",x$marker,"\n")
	cat("$info: ",x$info,"\n")
	cat("$winsize",x$winsize,"\n")
	cat("$location:\n")
	print(unlist(x$loc))
	cat("$summary:")
	print(x$summary)
	cat("$call: ")
	print(x$call)
	cat("\n")
}


