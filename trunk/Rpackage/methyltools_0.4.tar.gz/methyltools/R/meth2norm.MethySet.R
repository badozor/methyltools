meth2norm.MethySet <- function(x,method="normalize.quantiles",scaling=FALSE,chemistry=NULL,
	rev=FALSE,verbose=TRUE,add.UM=FALSE,...){
	if(!inherits(x,"MethylSet"))
		stop("non convenient argument!")
	if(!is.null(method))
		func <- get(method)
	U <- getUnmeth(x)
	M <- getMeth(x)
	samplenames <- colnames(U)
	probenames <- rownames(M)
	if(is.null(chemistry) && scaling){
		typeI <- data.frame(Name=getProbeInfo(x, type = "I")[, c("Name")])
		typeII <- data.frame(Name=getProbeInfo(x, type = "II")[, c("Name")])
		HMchemistry <- rbind(typeI, typeII)
		HMchemistry$type <- c(rep("I",nrow(typeI)),rep("II",nrow(typeII)))
		rownames(HMchemistry) <-  HMchemistry$Name
		HMchemistry <- HMchemistry[rownames(x),]
		chemistry <- HMchemistry$type
		names(chemistry) <- rownames(HMchemistry)
		if(verbose)
			table(names(chemistry)==rownames(x),useNA="always")		
	}
	if(scaling){
		if(rev){
			U <- apply(U,2, function(x) ifelse(chemistry=="I", x*sd(x[chemistry=="II"])/sd(x[chemistry=="I"]),x))
			M <- apply(M,2, function(x) ifelse(chemistry=="I", x*sd(x[chemistry=="II"])/sd(x[chemistry=="I"]),x))
		}else{
			U <- apply(U,2, function(x) ifelse(chemistry=="II", x*sd(x[chemistry=="I"])/sd(x[chemistry=="II"]),x))
			M <- apply(M,2, function(x) ifelse(chemistry=="II", x*sd(x[chemistry=="I"])/sd(x[chemistry=="II"]),x))
		}
	}
	if(!is.null(method)){
		UM <- cbind(U,M)
		UM <- func(UM,...)
		U <- UM[,1:ncol(U)]
		M <- UM[,(1+ncol(U)):(ncol(M)+ncol(U))]
	}
	T <- U+M
	rownames(U) <- rownames(M) <- rownames(T) <- probenames
	colnames(U) <- colnames(M) <- colnames(T) <- samplenames
	if(add.UM){
		res <- list(T=T,U=U,M=M)		
	}else{
		res <- list(T=T)
	}
	res$colnames <- samplenames
	res$rownames <- probenames
	res$chemistry <- chemistry
	res$call <- match.call()
	return(res)
}