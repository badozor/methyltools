normalUHM <- function(df,cpus=3,verbose=FALSE,...){
#	if(cpus>1){
		sfStop()
		sfInit(parallel=TRUE, cpus=cpus)
		sfLibrary("mixtools")
		sfExport("df")
		res <- sfApply(df,2,normalmixEM,k=3,...)
		sfStop()
		# posterior and categorization 	
		sfInit( parallel=TRUE, cpus=cpus)
		sfExport("res")
		sfExport("lim")
		for(i in 1:ncol(df)){
			if(verbose)
				print(paste(i,": ",colnames(df)[i],sep=""))
			res[[i]]$cluster <- unlist(sfApply(res[[i]]$posterior[,order(res[[i]]$mu)],1,function(x) c("U","H","M")[x==max(x)[1]]))
		}
		sfStop()
#	}else{	
#		.NotYetImplemented()
#	}
	return(res)	
}
