geneloc2IR <-
function(x,...){
	if(!inherits(x,"geneloc"))
		stop("non convenient argument!")
	IRanges(names=x$genename,start=x$txstart,end=x$txend,...)
}
