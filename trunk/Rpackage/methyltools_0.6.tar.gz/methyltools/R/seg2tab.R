# updated 2013-03-08
seg2tab <- function(x,...){
	cp <- copynumber(x)
	chrom  <- chromosomes(x)
	pos <- bpstart(x)
	res <- list()
	for(i in 1:ncol(cp)){
		segmentx <- CGHbase:::.makeSegments(segmented(x)[,i],chrom)
		w <- NULL
		for(k in (1:nrow(segmentx))) {
			w <- rbind(w,cbind(chrom[segmentx[k,2]],pos[segmentx[k,2]],pos[segmentx[k,3]],segmentx[k,3]-segmentx[k,2]+1,segmentx[k,1]))
		}
		colnames(w) <- c("chrom","start","end","num.mark","seg.mean")
		res[[i]] <- w
	}
	names(res) <- colnames(cp)
	return(res)
}
