logoffset <-
function(x,...,offset=0.0,method="only0"){
	switch(method, only0= ifelse(x==0,0+offset,log(x,...)),all= log(x+offset,...),stop("non convient method!"))
}
