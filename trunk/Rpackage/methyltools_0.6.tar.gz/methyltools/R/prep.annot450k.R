prep.annot450k <- function (object, ...){
	UseMethod("prep.annot450k")
}
prep.annot450kilm <-function(x,snp.rm=TRUE,sex.rm=TRUE,in27k=FALSE,chemistry=NULL){
	if(!inherits(x,"data.frame"))
		stop("object data.frame expected!")
	x$in27k <- ifelse(!is.na(x$Methyl27_Loci) & x$Methyl27_Loci,TRUE,FALSE)
	if(sex.rm)
		x <- x[!is.element(x$CHR,c("X","Y")),]
	if(snp.rm)
		x <- x[is.element(x$Probe_SNPs,c("")) & is.element(x$Probe_SNPs_10,c("")),]	
	if(in27k)		
		x <- x[x$in27k,]
	if(!is.null(chemistry))
		x[x$Infinium_Design_Type==chemistry,]
	x$CHR2 <- factor(as.character(x$CHR),levels=as.character(sort(as.numeric(levels(x$CHR)))))
	levels(x$CHR2)
	x[order(x$CHR2,x$MAPINFO),]	
}
prep.annot450k.MethylSet <-function(x,snp.rm=c("probe","cpg","sbe"),sex.rm=TRUE,in27k=FALSE,chemistry=NULL){
	if(!inherits(x,"MethylSet"))
		stop("object MethylSet expected!")
	annot0 <- as.data.frame(getAnnotation(x))
	# snp
	if(any(is.element(snp.rm,"probe")))
		annot0 <- annot0[is.na(annot0$Probe_rs),]
	if(any(is.element(snp.rm,"cpg")))
		annot0 <- annot0[is.na(annot0$CpG_rs),]	
	if(any(is.element(snp.rm,"sbe")))
		annot0 <- annot0[is.na(annot0$SBE_rs),]	
	# seannot0
	if(sex.rm)
		annot0 <- annot0[!is.element(annot0$chr,c("chrX","chrY")),]	
	# in27k	
	annot0$in27k <- ifelse(!is.na(annot0$Methyl27_Loci) & annot0$Methyl27_Loci=="TRUE",TRUE,FALSE)
	if(in27k)		
		annot0 <- annot0[annot0$in27k,]
	# chemistry
	if(!is.null(chemistry))
		annot0[annot0$Type==chemistry,]
	# recode chr
	annot0$chrnum <- c(1:24)[match(annot0$chr,c(paste("chr",1:22,sep=""),"chrX","chrY"))]
	annot0[order(annot0$chrnum,annot0$pos),]	
}
prep.annot450df <-function(x,snp.rm=c("probe","cpg","sbe"),sex.rm=TRUE,in27k=FALSE,chemistry=NULL){
	if(!inherits(x,"data.frame"))
		stop("object data.frame!")
	annot0 <- x
	# snp
	if(any(is.element(snp.rm,"probe")))
		annot0 <- annot0[is.na(annot0$Probe_rs),]
	if(any(is.element(snp.rm,"cpg")))
		annot0 <- annot0[is.na(annot0$CpG_rs),]	
	if(any(is.element(snp.rm,"sbe")))
		annot0 <- annot0[is.na(annot0$SBE_rs),]	
	# seannot0
	if(sex.rm)
		annot0 <- annot0[!is.element(annot0$chr,c("chrX","chrY")),]	
	# in27k	
	annot0$in27k <- ifelse(!is.na(annot0$Methyl27_Loci) & annot0$Methyl27_Loci=="TRUE",TRUE,FALSE)
	if(in27k)		
		annot0 <- annot0[annot0$in27k,]
	# chemistry
	if(!is.null(chemistry))
		annot0[annot0$Type==chemistry,]
	# recode chr
	annot0$chrnum <- c(1:24)[match(annot0$chr,c(paste("chr",1:22,sep=""),"chrX","chrY"))]
	annot0[order(annot0$chrnum,annot0$pos),]	
}
