geneloc2GR <-
function(x,...){
	if(!inherits(x,"geneloc"))
		stop("non convenient argument!")
	GRanges(seqnames=Rle(x$chrom),ranges=IRanges(names=x$genename,start=x$txstart,end=x$txend),strand=Rle(x$strand),...)
}
