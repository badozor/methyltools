gene2GR <-
function(gene,calls,...){
	.NotYetImplemented()
}
