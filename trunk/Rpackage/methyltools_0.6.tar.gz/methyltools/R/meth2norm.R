meth2norm <-
function(x,...){
	UseMethod("meth2norm")
}
