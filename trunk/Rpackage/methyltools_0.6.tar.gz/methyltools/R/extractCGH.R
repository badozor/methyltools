### 21-05-2014 modified by pbady
### 23-05-2014 modified by pbady
### 17-06-2014 modified by pbady
extractCGH <- function(x, ...){
    UseMethod("extractCGH")
}
extractCGH.gene <- function(x,gene,...){
	w <- getGeneLocationR(gene)
	chrtmp <- as.character(w$chrom)
	chrtmp <- as.numeric(substring(chrtmp,4,nchar(chrtmp)))
	extractCGH.default(x,chr=chrtmp,start=w$txstart,end=w$txend,info=gene,...)
} 
extractCGH.chr <- function(x,chr,...){
	if(substring(as.character(chr),1,3)=="chr"){
		chr <- as.character(chr)
		chr <- as.numeric(substring(chr,4,nchar(chr)))
	}
	res <- x[chromosomes(x)==chr,]
	attr(res,"loc") <- list(info=chr,chr=chr,start=NULL,end=NULL,winsize=0.0,mode=NULL)
	res
} 
#extractCGH.default <- function(x,chr, start,end,winsize=0.0,info=NULL,...){
#	if(substring(as.character(chr),1,3)=="chr"){
#		chr <- as.character(chr)
#		chr <- as.numeric(substring(chr,4,nchar(chr)))
#	}
#	res <- x[chromosomes(x)==chr & bpstart(x)>=(start-winsize) & bpend(x)<=(end+winsize) ,]
#	attr(res,"loc") <- list(info=info,chr=chr,start=start,end=end,winsize=winsize)
#	res
#} 
# w0 <- extractCGH.gene(gliomabatch6,"EGFR")
#w2 <- extractCGH2.default(gliomabatch6,"chr7",55086725,55275031)
#w1 <- extractCGH.default(gliomabatch6,"chr7",55086725,55275031)
extractCGH.default <- function(x,chr, start,end,winsize=0.0,info=NULL,mode=NULL,...){
	if(!inherits(x,"cghCall"))
		stop("non convenient argument!")
	if(substring(as.character(chr),1,3)=="chr"){
		chr <- as.character(chr)
		chr <- as.numeric(substring(chr,4,nchar(chr)))
	}
	chromInf <- chromosomes(x)
	IDprobeInf <- as.character(featureNames(x))
	bpstartInf <- bpstart(x)
	bpendInf <- bpend(x)
	callsInf <- calls(x)
	start <- start - winsize
	end <- end + winsize
	if(is.null(mode))
		mode <- c(1,2,3,4)
	if(!all(is.element(mode,c(1,2,3,4))))
		stop("non convenient mode!")
	selectx <- NULL
	# mode 1: | x------------x   |
	if(any(mode==1)) selectx <- c(selectx,which(chromInf == chr & bpstartInf >= start & bpendInf <= end))
	# mode 2: x------|------x   |
	if(any(mode==2)) selectx <- c(selectx,which(chromInf == chr & bpstartInf <= start & bpendInf >= start))	
	# mode 3: |    x------|------x
	if(any(mode==3)) selectx <- c(selectx,which(chromInf == chr & bpstartInf <= end & bpendInf >= end))	
	# mode 4: x------|----|--x
	if(any(mode==4)) selectx <- c(selectx,which(chromInf == chr & bpstartInf <= start & bpendInf >= end))
	selectx <- as.numeric(unique(selectx))
	res <- x[selectx,]
	attr(res,"loc") <- list(info=info,chr=chr,start=start,end=end,winsize=winsize,mode=mode)
	res	
}


